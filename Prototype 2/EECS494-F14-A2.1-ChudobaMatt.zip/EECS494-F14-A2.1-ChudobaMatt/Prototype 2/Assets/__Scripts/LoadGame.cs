﻿using UnityEngine;
using System.Collections;

public class LoadGame : MonoBehaviour
{
	void Start()
	{
		Application.LoadLevel("Menu_Scene");
	}
}
